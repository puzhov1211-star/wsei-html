BiletyLive — statyczny projekt HTML/CSS

Uruchomienie:
1. Otwórz plik index.html w przeglądarce.
2. Strona nie używa JavaScript.
3. Wszystkie przyciski prowadzą do odpowiednich podstron.

Struktura:
- index.html — strona główna
- concerts.html — lista koncertów
- concerts/ — szczegóły koncertów
- cities.html i cities/ — koncerty według miast
- artists.html — wykonawcy
- about.html — informacje i kontakt
- cart.html, cart-1.html, cart-3.html, cart-empty.html — koszyk z przyciskami + i -
- checkout.html — formularz zamówienia
- success.html — potwierdzenie
- css/style.css — osobny plik stylów

Kontakt: puzhov12.11@gmail.com
Założyciel: Igor Pyzhov
